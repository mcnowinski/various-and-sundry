import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.util.*;

import javax.swing.*;

public class Mission extends JPanel {
	
	private Orbit earth;
	private Orbit mars;
	private Orbit earth2Mars;
	private Orbit mars2Earth;

	private double day = 0; //time increment
    
    //private String commandString = "";
    
    private int width;
    private int height;
    
    private boolean showEarth2Mars = false;
    private boolean showMars2Earth = false;    
    
    private static final double scale = 125.0;  
    
    //orbital constants
	public static final double rEarth = 1.000;
	public static final double rMars = 1.524;
	public static final double eEarth = 0.000; /*0.0167*/
	public static final double eMars = 0.000; /*0.0935*/
	
	
	public static final double aMin_toMars = (rMars + rEarth) / 2.0;
	public static final double aMax_toMars = 5.0;
	public static final double aMin_toEarth = 0.8; /*rMars / 2.0*/
	public static final double aMax_toEarth = aMin_toMars;	
	
	public static final double eMax = 0.900;
	public static final double eMax_toMars = 1.0 - rEarth/aMax_toMars;	
	public static final double eMax_toEarth = rMars/aMin_toEarth - 1.0;	
	public static final double eMin = (rMars - rEarth) / (rMars + rEarth);
   
    
	public Mission () {
		earth = new Orbit("Earth", rEarth, eEarth);
		mars = new Orbit("Mars", rMars, eMars);
    	earth2Mars = new Orbit("Earth to Mars", aMin_toMars, eMin);
    	mars2Earth = new Orbit("Mars to Earth", aMax_toEarth, eMin);
    	mars2Earth.setOmega(180.0); //return trip
	}

    public void paint(Graphics g){
		//draw other stuff
        super.paint(g);

		//get current panel dimensions
		width = (int) this.getSize().getWidth();
		height = (int) this.getSize().getHeight();
		
		g.setColor(Color.WHITE);
		g.drawString("Keyboard Controls: +1 day (right arrow), -1 day (left arrow), x10 (hold CTRL)", 0, height-5);
		
        drawSun(g);
        drawPlanetOrbits(g);
        drawPlanets(g);

		//double a = (1.0+1.524)/2.0;
		//double e = 1.0-1.0/a;
		if(showEarth2Mars) {
			earth2Mars.setOmega(Math.toDegrees(earth.getPositionAt(day).getV()));
			drawEarth2MarsOrbit(g);
		}	
		if(showMars2Earth) {
			mars2Earth.setOmega(Math.toDegrees(mars.getPositionAt(day).getV())+180.0);			
			drawMars2EarthOrbit(g);
		}	
    }	
	
    public void setShowEarth2Mars(boolean show) {
    	showEarth2Mars = show;
    }

    public void setShowMars2Earth(boolean show) {
    	showMars2Earth = show;
    } 
    
	public double getDay() {
		return day;
	}
	
	public void setDay(double day) {
		this.day = day >= 0 ? day : 0.0;
	}
	
	public void incrementDay(double dDay) {
		if(day + dDay < 0)
			day = 0.0;
		else
			day += dDay;
	}

    public void drawSun(Graphics g) {
        //draw Sun
        g.setColor(Color.YELLOW); 
        g.fillOval(width/2-10, height/2-10, 20, 20);	
    }
    
    public void drawPlanetOrbits(Graphics g) {
        //draw Earth orbit
    	earth.drawOrbit(g, Color.BLUE, scale, width/2, height/2);
    	//earth.drawPosition(100, g, Color.BLUE, 100.0, width/2, height/2);
    	
    	//draw Mars orbit
		mars.drawOrbit(g, Color.RED, scale, width/2, height/2);
		//mars.drawPosition(100, g, Color.RED, 100.0, width/2, height/2);   	
    }
    
    public void drawEarth2MarsOrbit(Graphics g/*, double a, double e*/) {
    	//earth2Mars = new Orbit("Earth to Mars", a, e, Math.toDegrees(earth.getPositionAt(day).getV()));
		earth2Mars.drawOrbit(g, Color.WHITE, scale, width/2, height/2);
		
    	mars.drawPosition(day + earth2Mars.getPeriod()*365/2.0, g, Color.RED, false, scale,width/2, height/2);		
    }
    
    public void drawMars2EarthOrbit(Graphics g/*, double a, double e*/) {
    	//mars2Earth = new Orbit("Mars to Earth", a, e, Math.toDegrees(mars.getPositionAt(day).getV()) + 180.0);
    	mars2Earth.drawOrbit(g, Color.GREEN, scale, width/2, height/2);
    	
    	earth.drawPosition(day + mars2Earth.getPeriod()*365/2.0, g, Color.BLUE, false, scale,width/2, height/2);
    	
    	double [] psis = calcIntersectionMars2Earth();	
    	
        System.out.println("There are " + psis.length + " solution(s).");
        
        for(int i=0; i<psis.length; i++) {
        	mars2Earth.drawPosition(mars2Earth.psiToDay(psis[i]), g, Color.YELLOW, true, scale,width/2, height/2);
        	//System.out.println("psi=" + Math.toDegrees(psis[i]));
        }
    }
    
    public double [] calcIntersectionMars2Earth() {
    	double [] psis = new double[0];
    	
    	double a = mars2Earth.getSemimajorAxis();
    	double e = mars2Earth.getEccentricity();
        double r = rEarth;
        
        double parameter = (a-r)/(a*e);
        //round to two decimal places
        parameter = Math.round(parameter*100)/100.0;
        if(parameter > 1) {
        	//no solutions
        } else if(parameter == 1) {
        	psis = new double[1];
        	psis[0] = Math.acos(parameter);
        } else {
        	psis = new double[2];
        	psis[0] = Math.acos(parameter);
        	psis[1] = Math.acos(-parameter) + Math.PI;        	
        }
        
    	return psis;
    }
 
    public void drawPlanets(Graphics g) {
    	earth.drawPosition(day, g, Color.BLUE, true, scale, width/2, height/2);    	
		mars.drawPosition(day, g, Color.RED, true, scale, width/2, height/2);     	
    }
    
    public Orbit getEarth() {
    	return earth;
    }

    public Orbit getMars() {
    	return mars;
    } 
    
    public Orbit getMars2Earth() {
    	return mars2Earth;
    }

    public Orbit getEarth2Mars() {
    	return earth2Mars;
    } 
    
    
}
