import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class JourneyToMars extends JFrame implements ActionListener, ChangeListener {

	public class ChangeDay extends AbstractAction {

	    double dDay;
	    JourneyToMars j2m;

	    ChangeDay(JourneyToMars j2m, double dDay) {
	    	this.j2m = j2m;
	        this.dDay = dDay;
	    }

	    @Override
	    public void actionPerformed(ActionEvent e) {
	    	j2m.mission.incrementDay(dDay);
	    	j2m.repaint();
	    }
	}
	
	
	//private JPanel controls;
	private JButton reset;
	private JButton addDay;
	private JButton minusDay;
	//private JPanel data;
	private JTextPane dataText;
	private JTextField dayField;
	
	private JButton showEarth2Mars;
	private JButton showMars2Earth;	
	
	private Mission mission;
	private JPanel toMars;
	private JPanel toEarth;
	//private JLabel toMarsLabel;
	private JTextField semimajorAxis_toMars;
	//private JLabel semimajorAxisLabel_toMars;
	private JSlider semimajorAxisSlider_toMars;
	//private JLabel eccentricityLabeL_toMars;
	private JTextField eccentricity_toMars;
	//private JSlider eccentricitySlider_toMars;
	//private JLabel toEarthLabel;
	//private JLabel semimajorAxisLabel_toEarth;
	private JTextField semimajorAxis_toEarth;
	private JSlider semimajorAxisSlider_toEarth;
	private JTextField eccentricity_toEarth;
	//private JSlider eccentricitySlider_toEarth;
	//private JLabel eccentricityLabel_toEarth;

	private static final int sliderIncrement = 100;
	
	public void paint(Graphics g) {
		
		super.paint(g);
		
		dataText.setText(
				"Day =\t" + mission.getDay() + "\n" +
				"\nEarth:\n" +
				"a =\t" + String.format("%.3f", mission.getEarth().getSemimajorAxis()) + " AU\n" +
				"e =\t" + String.format("%.3f", mission.getEarth().getEccentricity()) + "\n" +		
				"T =\t" + String.format("%.3f", mission.getEarth().getPeriod()) + " years\n" +					
				"v =\t" + String.format("%.1f", Math.toDegrees(mission.getEarth().getPositionAt(mission.getDay()).getV())) + " deg\n" +
				"V =\t" + String.format("%.2f", mission.getEarth().getVelocity(mission.getDay())) + " m/s\n" +				
				"\nMars:\n" +				
				"a =\t" + String.format("%.3f", mission.getMars().getSemimajorAxis()) + " AU\n" +
				"e =\t" + String.format("%.3f", mission.getMars().getEccentricity()) + "\n" +	
				"T =\t" + String.format("%.3f", mission.getMars().getPeriod()) + " years\n" +	
				"v =\t" + String.format("%.1f", Math.toDegrees(mission.getMars().getPositionAt(mission.getDay()).getV())) + " deg\n" +
				"V =\t" + String.format("%.2f", mission.getMars().getVelocity(mission.getDay())) + " m/s\n"	+
				"\nEarth to Mars:\n" +				
				"a =\t" + String.format("%.3f", mission.getEarth2Mars().getSemimajorAxis()) + " AU\n" +
				"e =\t" + String.format("%.3f", mission.getEarth2Mars().getEccentricity()) + "\n" +	
				"T =\t" + String.format("%.3f", mission.getEarth2Mars().getPeriod()) + " years\n" +	
				"\nMars to Earth:\n" +				
				"a =\t" + String.format("%.3f", mission.getMars2Earth().getSemimajorAxis()) + " AU\n" +
				"e =\t" + String.format("%.3f", mission.getMars2Earth().getEccentricity()) + "\n" +	
				"T =\t" + String.format("%.3f", mission.getMars2Earth().getPeriod()) + " years\n"
				);
		
		dayField.setText(String.format("%.1f",  mission.getDay()));
		semimajorAxis_toMars.setText(String.format("%.3f",  mission.getEarth2Mars().getSemimajorAxis()));
		semimajorAxis_toEarth.setText(String.format("%.3f",  mission.getMars2Earth().getSemimajorAxis()));	
		eccentricity_toMars.setText(String.format("%.3f",  mission.getEarth2Mars().getEccentricity()));
		eccentricity_toEarth.setText(String.format("%.3f",  mission.getMars2Earth().getEccentricity()));
	}

	@Override	
    public void stateChanged(ChangeEvent event) {
		if(event.getSource() == semimajorAxisSlider_toEarth) {
            if(!semimajorAxisSlider_toEarth.getValueIsAdjusting())
            {
    			int value = semimajorAxisSlider_toEarth.getValue();
    			double a = Mission.aMin_toEarth + (Mission.aMax_toEarth-Mission.aMin_toEarth) / ((double) sliderIncrement) * value;
    			mission.getMars2Earth().setSemimajorAxis(a);				
    			//adjust eccentricity accordingly
    			mission.getMars2Earth().setEccentricity(Mission.rMars/a-1.0);	
            }
		} else if(event.getSource() == semimajorAxisSlider_toMars) {
            if(!semimajorAxisSlider_toMars.getValueIsAdjusting())
            {
    			int value = semimajorAxisSlider_toMars.getValue();
    			double a = Mission.aMin_toMars + (Mission.aMax_toMars-Mission.aMin_toMars) / ((double) sliderIncrement) * value;  			
    			mission.getEarth2Mars().setSemimajorAxis(a);			
    			//adjust eccentricity accordingly
    			mission.getEarth2Mars().setEccentricity(1.0-Mission.rEarth/a);	    			
            }			
		}
		
		mission.requestFocusInWindow();
		
		repaint();		
    }	
	
	@Override
	public void actionPerformed(ActionEvent event) {	
		
		if(event.getSource() == reset) {
			mission.setDay(0.0);
		} else if(event.getSource() == addDay) {
			mission.incrementDay(1.0);
		} else if(event.getSource() == minusDay) {
			mission.incrementDay(-1.0);
		} else if(event.getSource() == dayField) {
			double day = Double.parseDouble(dayField.getText());
			if(day >= 0)
				mission.setDay(day);
		} else if(event.getSource() == semimajorAxis_toMars) {
			double a_toMars = Double.parseDouble(semimajorAxis_toMars.getText());
			if(a_toMars > Mission.aMax_toMars)
				a_toMars = Mission.aMax_toMars;
			else if(a_toMars < Mission.aMin_toMars)
				a_toMars = Mission.aMin_toMars;
			mission.getEarth2Mars().setSemimajorAxis(a_toMars);				
			//adjust eccentricity accordingly
			mission.getEarth2Mars().setEccentricity(1.0-Mission.rEarth/a_toMars);			
		} else if(event.getSource() == semimajorAxis_toEarth) {
			double a_toEarth = Double.parseDouble(semimajorAxis_toEarth.getText());
			if(a_toEarth > Mission.aMax_toEarth)
				a_toEarth = Mission.aMax_toEarth;
			else if(a_toEarth < Mission.aMin_toEarth)
				a_toEarth = Mission.aMin_toEarth;				
			mission.getMars2Earth().setSemimajorAxis(a_toEarth);			
			//adjust eccentricity accordingly
			mission.getMars2Earth().setEccentricity(Mission.rMars/a_toEarth-1.0);
		} else if(event.getSource() == eccentricity_toMars) {
			double e_toMars = Double.parseDouble(eccentricity_toMars.getText());
			if(e_toMars > Mission.eMax_toMars)
				e_toMars = Mission.eMax_toMars;
			else if(e_toMars < Mission.eMin)
				e_toMars = Mission.eMin;
			mission.getEarth2Mars().setEccentricity(e_toMars);				
			//adjust semimajor accordingly
			mission.getEarth2Mars().setSemimajorAxis(Mission.rEarth/(1-e_toMars));			
		} else if(event.getSource() == eccentricity_toEarth) {
			double e_toEarth = Double.parseDouble(eccentricity_toEarth.getText());
			if(e_toEarth > Mission.eMax_toEarth)
				e_toEarth = Mission.eMax_toEarth;
			else if(e_toEarth < Mission.eMin)
				e_toEarth = Mission.eMin;
			mission.getMars2Earth().setEccentricity(e_toEarth);				
			//adjust semimajor accordingly
			mission.getMars2Earth().setSemimajorAxis(Mission.rMars/(1+e_toEarth));	
		} else if(event.getSource() == showEarth2Mars) {
			if(event.getActionCommand().equals("show")) {
				showEarth2Mars.setActionCommand("hide");
				showEarth2Mars.setText("Hide Departure");
				mission.setShowEarth2Mars(true);
			} else {
				showEarth2Mars.setActionCommand("show");				
				showEarth2Mars.setText("Show Departure");
				mission.setShowEarth2Mars(false);
			}
		} else if(event.getSource() == showMars2Earth) {
			if(event.getActionCommand().equals("show")) {
				showMars2Earth.setActionCommand("hide");
				showMars2Earth.setText("Hide Return");
				mission.setShowMars2Earth(true);
			} else {
				showMars2Earth.setActionCommand("show");				
				showMars2Earth.setText("Show Return");
				mission.setShowMars2Earth(false);
			}
		}
			
		//mission.calcIntersectionMars2Earth();
		
		mission.requestFocusInWindow();
		
		repaint();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JourneyToMars window = new JourneyToMars();
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JourneyToMars() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		mission = new Mission();
		
		//build the GUI
		this.setResizable(false);
		this.setTitle("Journey To Mars");
		this.setBounds(100, 100, 700, 571);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel bottom = new JPanel(new GridLayout(3,1));
		this.getContentPane().add(bottom, BorderLayout.SOUTH);
		
		JPanel controls = new JPanel();
		controls.setBorder(UIManager.getBorder("MenuBar.border"));
		FlowLayout flowLayout = (FlowLayout) controls.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		//this.getContentPane().add(controls, BorderLayout.SOUTH);
		bottom.add(controls);
		
		reset = new JButton("Reset");
		controls.add(reset);
        reset.addActionListener(this);
		
		JLabel daysLabel = new JLabel();
		daysLabel.setText("Day: ");
		controls.add(daysLabel);
		
		dayField = new JTextField();
		dayField.setColumns(5);
		controls.add(dayField);
		dayField.addActionListener(this);
		
		addDay = new JButton("+");
		controls.add(addDay);		
		addDay.addActionListener(this);
		
		minusDay = new JButton("-");
		controls.add(minusDay);
		minusDay.addActionListener(this);
		
		showEarth2Mars = new JButton("Show Departure");
		controls.add(showEarth2Mars);
		showEarth2Mars.addActionListener(this);
		showEarth2Mars.setActionCommand("show");		

		showMars2Earth = new JButton("Show Return");
		controls.add(showMars2Earth);
		showMars2Earth.addActionListener(this);
		showMars2Earth.setActionCommand("show");	
		
		toMars = new JPanel();
		toMars.setBorder(UIManager.getBorder("MenuBar.border"));
		bottom.add(toMars);
		toMars.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		
		JLabel toMarsLabel = new JLabel("Earth To Mars:");
		toMarsLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		toMars.add(toMarsLabel);
		
		JLabel semimajorAxisLabel_toMars = new JLabel("a (AU):");
		toMars.add(semimajorAxisLabel_toMars);
		
		semimajorAxis_toMars = new JTextField();
		semimajorAxis_toMars.setColumns(10);
		toMars.add(semimajorAxis_toMars);
		semimajorAxis_toMars.addActionListener(this);
	
		semimajorAxisSlider_toMars = new JSlider(0, sliderIncrement, 0);
		semimajorAxisSlider_toMars.setPreferredSize(new Dimension(100, 23));
		toMars.add(semimajorAxisSlider_toMars);
		semimajorAxisSlider_toMars.addChangeListener(this);
		
		JLabel eccentricityLabeL_toMars = new JLabel("e:");
		toMars.add(eccentricityLabeL_toMars);
		
		eccentricity_toMars = new JTextField();
		eccentricity_toMars.setColumns(10);
		toMars.add(eccentricity_toMars);
		eccentricity_toMars.addActionListener(this);
		
//		eccentricitySlider_toMars = new JSlider();
//		eccentricitySlider_toMars.setPreferredSize(new Dimension(100, 23));
//		toMars.add(eccentricitySlider_toMars);
		
		toEarth = new JPanel();
		toEarth.setBorder(UIManager.getBorder("MenuBar.border"));
		bottom.add(toEarth);
		toEarth.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		
		JLabel toEarthLabel = new JLabel("Mars to Earth:");
		toEarthLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		toEarth.add(toEarthLabel);
		
		JLabel semimajorAxisLabel_toEarth = new JLabel("a (AU):");
		toEarth.add(semimajorAxisLabel_toEarth);

		semimajorAxis_toEarth = new JTextField(Double.toString(Mission.aMax_toEarth));
		semimajorAxis_toEarth.setColumns(10);
		toEarth.add(semimajorAxis_toEarth);
		semimajorAxis_toEarth.addActionListener(this);		
		
		semimajorAxisSlider_toEarth = new JSlider(0, sliderIncrement, sliderIncrement);
		semimajorAxisSlider_toEarth.setPreferredSize(new Dimension(100, 23));
		toEarth.add(semimajorAxisSlider_toEarth);
		semimajorAxisSlider_toEarth.addChangeListener(this);		
		
		JLabel eccentricityLabel_toEarth = new JLabel("e:");
		toEarth.add(eccentricityLabel_toEarth);
		
		eccentricity_toEarth = new JTextField();
		eccentricity_toEarth.setColumns(10);
		toEarth.add(eccentricity_toEarth);
		eccentricity_toEarth.addActionListener(this);		

//		eccentricitySlider_toEarth = new JSlider();
//		eccentricitySlider_toEarth.setPreferredSize(new Dimension(100, 23));
//		toEarth.add(eccentricitySlider_toEarth);		
		
		JPanel data = new JPanel();
		data.setAlignmentX(Component.LEFT_ALIGNMENT);
		data.setPreferredSize(new Dimension(200, 10));
		data.setBackground(Color.BLACK);
		this.getContentPane().add(data, BorderLayout.WEST);
		data.setLayout(new BorderLayout(0, 0));
		
		dataText = new JTextPane();
		dataText.setFocusCycleRoot(false);
		dataText.setFocusTraversalKeysEnabled(false);
		dataText.setFocusable(false);
		dataText.setAlignmentX(Component.LEFT_ALIGNMENT);
		dataText.setForeground(Color.WHITE);
		dataText.setBackground(Color.BLACK);
		dataText.setText("This is a test!");
		dataText.setEditable(false);
		data.add(dataText);
		
		mission.setBackground(Color.BLACK);
		mission.setPreferredSize(new Dimension(300, 0));
		this.getContentPane().add(mission, BorderLayout.CENTER);
		
		JPanel panel = (JPanel) this.getContentPane();
		panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "addDay");
		panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "minusDay");
		panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, java.awt.event.InputEvent.CTRL_DOWN_MASK), "addTenDays");
		panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, java.awt.event.InputEvent.CTRL_DOWN_MASK), "minusTenDays");        
		panel.getActionMap().put("addDay", new ChangeDay(this, 1.0));
		panel.getActionMap().put("minusDay", new ChangeDay(this, -1.0));
		panel.getActionMap().put("addTenDays", new ChangeDay(this, 10.0));
		panel.getActionMap().put("minusTenDays", new ChangeDay(this, -10.0)); 
	}

}
