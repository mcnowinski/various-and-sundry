public class Position {
	
	private double x; //y pos in AU
	private double y; //x pos in AU
	private double v; //true anomaly
	private double t; //time in percent of orbital period (T)
	
	public Position(double x, double y, double v, double t) {
		this.x = x;
		this.y = y;
		this.v = v;
		this.t = t;
	}
	
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getV() {
		return v;
	}	

	public double getT() {
		return t;
	}
	
	public void print() {
		System.out.println("*");
		System.out.println("x (AU): " + x);		
		System.out.println("y (AU): " + y);	
		System.out.println("True anomaly, v (deg): " + Math.toDegrees(v));
		System.out.println("Time/T: " + t);
		System.out.println("*");		
	}
}